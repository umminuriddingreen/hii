# Termite Release Staging

This folder contains staged release artifacts:

- `yak/termite`: Rhino Package Manager/Yak package contents.
- `mcp-server`: built MCP server package contents.

To create a Yak package on a Rhino/Yak-enabled machine:

```bash
cd outputs/release/yak/termite
yak build
```

Use `docs/production-installation.md` for end-user install instructions.