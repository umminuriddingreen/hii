# Termite

Termite is a local-first AI automation layer for Rhino 8 and Grasshopper. It lets MCP-compatible agents control Rhino through a localhost JSON protocol without cloud modeling credits or remote geometry processing.

```
AI agent -> Termite MCP server -> localhost WebSocket -> Termite Rhino bridge -> Rhino 8 + Grasshopper
```

## V0.1 Scope

- TypeScript MCP server over stdio.
- Local WebSocket client for a Rhino bridge at `ws://127.0.0.1:5977/ws`.
- Permission model with `READ_ONLY`, `EDIT_SAFE`, `EDIT_DESTRUCTIVE`, and `SYSTEM`.
- Structured JSON request and response protocol with request IDs, durations, warnings, and errors.
- Rhino 8 C# bridge skeleton with start/stop commands and service-oriented dispatch.
- Implemented bridge tools for ping, document state, layer creation, object listing, command execution, box/polyline creation, capture, export, and printability checks.
- Professional proof-loop tools: export-readiness validation, validation report generation, and guarded workflow execution.
- Grasshopper API scaffold for V0.1-safe future implementation.
- Plugin adapter manifests and workflow recipe docs.

## Requirements

- Node.js 20 or newer.
- Rhino 8 for Windows for the bridge plugin.
- .NET SDK that can restore/build Rhino plugin projects.
- RhinoCommon/RhinoWindows assemblies available through Rhino or NuGet.

## Install

```bash
npm install
npm run build
```

For production-oriented packaging, see [docs/production-installation.md](docs/production-installation.md).

## Run MCP Server

```bash
termite
```

Environment variables:

- `RHINO_MCP_BRIDGE_URL`: WebSocket URL for the bridge. Default: `ws://127.0.0.1:5977/ws`.
- `RHINO_MCP_PERMISSION`: Default permission level. Default: `READ_ONLY`.
- `RHINO_MCP_AUDIT_LOG`: Audit log file. Default: `./rhino-mcp-audit.jsonl`.

## Rhino Bridge

Build the bridge project:

```bash
dotnet restore apps/rhino-bridge/RhinoMcpBridge.csproj
dotnet build apps/rhino-bridge/RhinoMcpBridge.csproj
```

In Rhino 8, load the plugin and run:

```text
StartTermiteBridge
```

Then start the MCP server and call `rhino.ping`.

## First Professional Workflow

`rhino.run_workflow` currently supports:

- `fabrication.bauhaus_valet_tray`

It creates a Bambu-sized Bauhaus tray model, selects the generated objects, and validates footprint/export readiness. Inline workflow exports are temporarily disabled on macOS while hardened non-modal exporters are implemented.

## Package For Rhino Users

Stage release artifacts:

```bash
npm run release:stage
```

This creates:

- `outputs/release/yak/termite`: Rhino Package Manager/Yak package contents.
- `outputs/release/mcp-server`: built MCP server package contents.

On a Rhino/Yak-enabled machine:

```bash
cd outputs/release/yak/termite
yak build
```

MCP client config examples are in [examples/mcp-clients](examples/mcp-clients).

For local macOS alpha installs:

```bash
npm run install:rhino-mac
```

Restart Rhino 8, then run `StartTermiteBridge` or the compatibility alias `StartRhinoMcpBridge`.

## Safety Defaults

The MCP server starts in `READ_ONLY`. Read and validation tools work by default. Geometry creation requires `EDIT_SAFE`; delete, destructive edits, and overwriting exports require `EDIT_DESTRUCTIVE`; arbitrary script execution is reserved for `SYSTEM`.

See [docs/security.md](docs/security.md) for the full model.

## Manual Validation

See [docs/manual-test-plan.md](docs/manual-test-plan.md).
