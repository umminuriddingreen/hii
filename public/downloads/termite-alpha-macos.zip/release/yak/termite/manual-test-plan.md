# Manual Test Plan

Run these tests in Rhino 8 on Windows after building and loading the plugin.

1. Install or load the Rhino bridge plugin.
2. Run `StartTermiteBridge` or compatibility alias `StartRhinoMcpBridge`.
3. Start the MCP server with `RHINO_MCP_PERMISSION=EDIT_SAFE`.
4. Call `rhino.ping`.
5. Call `rhino.get_document_state`.
6. Create a layer named `03_PRINT_PARTS`.
7. Create a `100 x 80 x 20 mm` box on `03_PRINT_PARTS`.
8. Create a closed polyline.
9. Call `rhino.list_objects`.
10. Select the created box with `rhino.select_objects`.
11. Capture the Perspective viewport with `rhino.capture_view`.
12. Restart the MCP server with `RHINO_MCP_PERMISSION=EDIT_DESTRUCTIVE`.
13. Export the selected object as STL.
14. Run `rhino.check_3d_printability`.
15. Run `rhino.validate_export_readiness` for STL with expected units set to millimeters.
16. Run `rhino.generate_validation_report` with a Markdown `report_path`.
17. Run `rhino.run_workflow` with `workflow=fabrication.bauhaus_valet_tray`.
18. Run `rhino.export_file` separately only after confirming the export path and Rhino export options; inline workflow exports are disabled during macOS crash hardening.
19. Open a Grasshopper definition when Grasshopper integration is implemented.
20. Set a slider value.
21. Solve the definition.
22. Bake output geometry.

Expected behavior: every tool returns structured JSON with `success`, `message`, `warnings`, `errors`, and `duration_ms`.
